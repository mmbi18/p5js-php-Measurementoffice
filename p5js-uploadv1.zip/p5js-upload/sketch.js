var strokeColor = 'black';
var strokeWIDTH = 2;
var colorPalette = ['red','orange','yellow','lime','blue','purple',
                    'pink','cyan','maroon','green','black','white'];
var cpRows = 6; // number of colors divided by 2
var palettes = [];
var d=30; //diameter of color palette samples
var pHeight;
let inputElement;
let userImage;
var hedtext='-';
function handleFile(file) {
  print(file);

  if (file.type === 'image') {
    userImage = createImg(file.data, '');
    userImage.hide();
  } else {
    userImage = null;
  }
}
function setup() { 
  createCanvas(windowWidth-(windowWidth/2), windowHeight-(windowHeight/1.8));
 //-----------------------------
 let inp = createInput(' ');
 
  inp.position(0,0);
  inp.size(90);
  inp.input(myInputEvent);
 //-*****************
 selm = createSelect();
  selm.position(150, 0);
  selm.option('-محصول-');
  selm.option('درب آکاردونی');
  selm.option('شاخ گوزنی');
  selm.option('دیگر');
  selm.selected('-');
  //selm.changed(mySelectEvent);
  //---------------------------------
 selc = createSelect();
  selc.position(250, 0);
  selc.option('-رنگ-');
  selc.option('مسی چکشی');
  selc.option('قهوه ای سوخته');
  selc.option('مشکی');
  selc.option('سفید');
  selc.option('کرم');
  selc.selected('-رنگ-');
  //selc.changed(mySelectEvent);
  //---------------------------------
  inputElement = createFileInput(handleFile);
  inputElement.position(0, 80);
  inputElement.size(30,30);
  //--------------------
  background(150);
  
  // drawing canvas
  strokeWeight(0);
  fill('khaki');
  rect(100,0,windowWidth, windowHeight);
	// color pallete
  for(var i = 0; i < 2; i++) {
    for(var j = 0; j < cpRows; j++) {
      var c = (i)+(j*2);
      var x = 30+i*40;
      var y = 30+j*40;
      fill(colorPalette[c]);
      ellipse(x,y,d);
      palettes.push(new Palette(x,y,c));
      pHeight = y + d;
      print(pHeight);
    }
  }
  // new canvas button
  strokeWeight(1);
  stroke(80);
  rect(7,pHeight+70,86,30);
  fill(0);
  strokeWeight(0);
  noStroke();
  textStyle(BOLD);
  txtCanvas='ایجاد مجدد';
  text(txtCanvas,10,pHeight+90);
}

function myInputEvent() {
    hedtext=this.value();

  console.log('you are typing: ', this.value());
}
// Palette object will store information about color swatches
function Palette(x,y,c) {
  this.x = x;
  this.y = y;
  this.pColor = c;
  print("x = " + this.x + ", y = " + this.y + ", pColor = " + this.pColor);
}
var txttmp='';
function mouseDragged() {
  // display current brush color and size
  if(mouseIsPressed){
  rectMode(CENTER);
  strokeWeight(0);
  fill(150);
  rect(50,pHeight+20,50,50);
  strokeWeight(1);
  stroke(strokeColor);
  fill(strokeColor);
  ellipse(50,pHeight+20,strokeWIDTH);
  // set stroke and strokeWeight to user settings
  stroke(strokeColor);
  strokeWeight(strokeWIDTH);
  if (txttmp!=hedtext){
  textFont('Georgia');
  textSize(14);
  text(hedtext, 100,50);
 
let result00 = hedtext.includes('*');
if(result00){
  let splitString = split(hedtext, '*');
noFill();

  rect(200, 200, splitString[0], splitString[1]);
}
  }
	if(mouseIsPressed && mouseX>100 && pmouseX>100) {
  	line(mouseX,mouseY,pmouseX,pmouseY)
  }

  }
}
starttma=0;
function draw() {
    if (userImage != null) {
    image(userImage, 0, 0, width, height);
  }
  if(mouseIsPressed && mouseX<100) {
    // check if user is clicking on a color palette
    var a;
    for(var i = 0; i < 8; i++) {
      a = dist(palettes[i].x,palettes[i].y,mouseX,mouseY);
      if(a < d) {
        strokeColor = colorPalette[palettes[i].pColor];
        print("palette color = " + strokeColor);
      }
    }
    // check if user is clicking on New Canvas button
    if(mouseX>8 && mouseX<92 && mouseY>pHeight+70 && mouseY<pHeight+100) {
      fill('khaki');
      strokeWeight(0);
      rectMode(CORNER);
		  rect(100,0,windowWidth, windowHeight);
    }
  }

    if(starttma==0){
  //text(txtCanvas,10,pHeight+90);
fill(0, 102, 153);

text('imenkv.ir',10,pHeight+120);
txttma='ایمن کاران وحدت';
text(txttma,10,pHeight+130);
//getDate()
let h = hour();
let m = minute();
let s = second();

txttma=getDate()+ "\n"+h+':'+ m + ':' + s;
text(txttma,10,pHeight+150);

//---
text('www.t-ma.ir',10,pHeight+250);
txttma='گروه نرم افزاری تیما';
text(txttma, 10,pHeight+260);
starttma=1;
        
    }
        
    }


// use number keys to change the strokeWeight of the line
function keyTyped() {
  if (key === '1') {
    strokeWIDTH = 2;
  } else if (key === '2') {
    strokeWIDTH = 4;
  } else if (key === '3') {
    strokeWIDTH = 6;
  } else if (key === '4') {
    strokeWIDTH = 8;
  } else if (key === '5') {
    strokeWIDTH = 10;
  } else if (key === '6') {
    strokeWIDTH = 20;
  } else if (key === '7') {
    strokeWIDTH = 30;
  } else if (key === '8') {
    strokeWIDTH = 40;
  } else if (key === '9') {
    strokeWIDTH = 50;
  } 

    
}

function getDate()
{
  let date = new Date();
  function formateDate()
  {
    return date.toDateString().slice(4);
  }
  
  return formateDate();
  
}