<?php
//-------------------------------------------------------
$upload_dir = "upload/";
$img = $_POST['hidden_data'];
$img = str_replace('data:image/png;base64,', '', $img);
$img = str_replace(' ', '+', $img);
$data = base64_decode($img);
$file = $upload_dir . mktime() . ".png";
$success = file_put_contents($file, $data);
//------------------------------------------------------
//*****************************************************
/*
    ini_set("soap.wsdl_cache_enabled", "0");

$sms_client = new SoapClient('https://portal.amootsms.com/webservice2.asmx?wsdl', array('encoding'=>'UTF-8'));

$parameters['UserName'] = "";
$parameters['Password'] = "";

$nowIran = new DateTime('now', new DateTimeZone('IRAN'));
$parameters['SendDateTime'] = $nowIran->format('c');

$parameters['SMSMessageText'] = "پیامک تستی من";
$parameters['LineNumber'] = "public";
$parameters['Mobiles'] =array("", "998123456987");

$result = $sms_client->SendSimple($parameters)->SendSimpleResult;
echo $result;
*/
$url = "https://portal.amootsms.com/rest/SendSimple";

$url = $url."?"."Token=".urlencode("");
$nowIran = new DateTime('now', new DateTimeZone('IRAN'));
$url = $url."&"."SendDateTime=".urlencode($nowIran->format('c'));
$smstxt='یک حواله سیستمی به نام';

$smsname=$_POST['name'];
$smsnum=$_POST['number'] .' '. $smsname . ' ';
$smstxt2=' و تلفن '. $smsnum .' ایجاد شد. ' ;
$smstxt= $smstxt.$smstxt2 ;
$url = $url."&"."SMSMessageText=".urlencode($smstxt);
$url = $url."&"."LineNumber=Service";

$url = $url."&"."Mobiles=9144522225522,998123465698";

$json = file_get_contents($url);
echo $json;
//+++++++++++++++++++++++++++++++++++++++

//$result = json_decode($json);
//echo $result->Status;
//*****************************************************
print $success ? $file : 'Unable to save the file.';
?>