var index = 1;
function setup(){
createCanvas(700, 700); 
}
function draw(){
//draw something
}
function keyPressed(){
makeScreenshot();
}
function makeScreenshot(){
var canvas = $('canvas')[0];
var data = canvas.toDataURL('image/png').replace(/data:image\/png;base64,/, '');

// make names  eg "img_1.png", "img_2.png"......etc"
var iname = 'img_' + index + '.png'; 

$('canvas').remove();
//post to php
$.post('save.php',{data: data, iname });
// update counter
index++;
//restart sketch
setup();
            }